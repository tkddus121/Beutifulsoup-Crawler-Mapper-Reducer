+_____________________________________+

	20141549 README

	Project environment : Linux
	Execute environment : Linux

	Object :
	
	Using Language corpus from Project5 
	we made BigData Bigram Language model.
	This project is searching Language model using
	distributed database using python and AWS DYNAMODB.

+_____________________________________+
