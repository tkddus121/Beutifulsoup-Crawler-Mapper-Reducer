+______________________________+
	
	20141549 README

	Project environment : Linux
	Execute environment : Linux

	What is object?

	: By using Python and Python libraries, BeautifulSoup4 and Requests, visit website's
      all hyperlink reculsively and crawl text of pages.
	  

	How to run?

	: python [filename]
	
	In this project, "python 20141549.py".

	Documentation:

	For this project, we crawl visit all website and hyperlink of them.
	Then crawl all texts of them by using Python and Python libraries that 
	are BeautifulSoup4 and Requests.
	For reliability, used try - except keyword. And to remember visited URL 
	Also root page is "http://cspro.sogang.ac.kr/~gr120160213/index.html".
	Crawling datas saved at Output files which names are form "Output_0000.txt"
	to "Output_00(link number).txt". 
	Last, visited URL saved "URL.txt" file.

	Thank you.

+______________________________+
