+_____________________________________+

	20141549 README

	Project environment : Linux
	Execute environment : Linux

	Object :
	
	For this project, from big-data corpus generate
	Bigram(N-Gram ,N=2) language model by distributed
	processing on Python and AWS Elastic MapReduce system.


+_____________________________________+
